"""
remplace_v9.py
Verifie et copie les fichiers du package vers prog.
Affiche la versiode chaque fichier source et cible.

Usage : python remplace_v9.py
"""
import shutil
import sys
import re
from pathlib import Path

version = ("remplace_v9.py", "9.0")

# ─────────────────────────────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────────────────────────────
RACINE   = Path("C:/SiteGITHUB/Hebreu4.0")
SRC      = RACINE / "package" / "prog"
DST      = RACINE / "prog"
LIB      = DST / "lib1"

# (fichier_source, fichier_cible, obligatoire)
FICHIERS = [
    # prog\
    ("genere_site_v25.1.py",      DST  / "genere_site.py",        True),
    ("settings_v1.0.py",          DST  / "settings.py",           True),
    ("documents_v2.1.py",         DST  / "documents.py",          True),
    ("builder_v1.0.py",           DST  / "builder.py",            True),
    ("docx_to_pdf_v1.3.py",       DST  / "docx_to_pdf.py",        True),
    ("musique_v1.10.py",          DST  / "musique.py",            True),
    ("place_bouton_v01.py",       DST  / "place_bouton.py",       True),
    ("versions_v1.0.py",          DST  / "versions.py",           False),
    # lib1\
    ("structure_utils_v2.1.py",   LIB  / "structure_utils.py",    True),
    ("lib1_options_shim_v2.0.py", LIB  / "options.py",            False),
    ("lib1_config_shim_v4.0.py",  LIB  / "config.py",             False),
]

SUPPRIMER = [
    LIB / "partition_utils.py",
    DST / "place_bouton_v01.py",    # ancien nom avec version
    DST / "Place_Bouton_PDF.py",    # tres ancien nom
]


# ─────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────
def extraire_version(chemin: Path) -> str:
    """Lit la ligne 'version = (...)' dans un fichier Python."""
    try:
        contenu = chemin.read_text(encoding="utf-8", errors="ignore")
        m = re.search(r'version\s*=\s*\([^,]+,\s*["\']([^"\']+)["\']', contenu)
        if m:
            return m.group(1)
        # Fallback : chercher '— Version X.Y' dans commentaire
        m = re.search(r'Version\s+([\d.]+)', contenu)
        if m:
            return m.group(1)
    except Exception:
        pass
    return "?"


def afficher_ligne(statut: str, src_rel: str, dst_rel: str,
                   ver_src: str, ver_dst: str, note: str = ""):
    print(f"  {statut:<8} {src_rel:<35} -> {dst_rel:<30}"
          f"  src=v{ver_src}  dst=v{ver_dst}"
          + (f"  [{note}]" if note else ""))


# ─────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────
def main():
    print()
    print("=" * 70)
    print(f"  remplace_v9.py — verification et deploiement")
    print(f"  Source  : {SRC}")
    print(f"  Dest    : {DST}")
    print("=" * 70)

    erreurs  = 0
    copies   = 0
    a_jour   = 0

    # Verifier existence des dossiers
    for d in (SRC, DST, LIB):
        if not d.exists():
            print(f"  ERREUR : dossier introuvable : {d}")
            erreurs += 1

    if erreurs:
        print(f"\n  {erreurs} erreur(s) — arret.")
        sys.exit(1)

    print()
    print("  Fichiers a deployer :")
    print()

    for nom_src, chemin_dst, obligatoire in FICHIERS:
        chemin_src = SRC / nom_src
        src_rel    = str(chemin_src.relative_to(RACINE))
        dst_rel    = str(chemin_dst.relative_to(RACINE))

        if not chemin_src.exists():
            if obligatoire:
                afficher_ligne("ABSENT", src_rel, dst_rel, "?", "?", "OBLIGATOIRE")
                erreurs += 1
            else:
                afficher_ligne("ABSENT", src_rel, dst_rel, "?", "?", "optionnel")
            continue

        ver_src = extraire_version(chemin_src)
        ver_dst = extraire_version(chemin_dst) if chemin_dst.exists() else "—"

        if ver_src == ver_dst:
            afficher_ligne("OK", src_rel, dst_rel, ver_src, ver_dst, "a jour")
            a_jour += 1
        else:
            shutil.copy2(str(chemin_src), str(chemin_dst))
            afficher_ligne("COPIE", src_rel, dst_rel, ver_src, ver_dst)
            copies += 1

    # Suppressions
    print()
    print("  Fichiers a supprimer :")
    print()
    for chemin in SUPPRIMER:
        rel = str(chemin.relative_to(RACINE)) if RACINE in chemin.parents else str(chemin)
        if chemin.exists():
            chemin.unlink()
            print(f"  SUPPRIME {rel}")
        else:
            print(f"  ABSENT   {rel}  (deja supprime)")

    # Bilan
    print()
    print("=" * 70)
    if erreurs:
        print(f"  ATTENTION : {erreurs} erreur(s) — verifier les fichiers ABSENT ci-dessus")
    else:
        print(f"  OK : {copies} copie(s)  {a_jour} deja a jour")
    print("=" * 70)
    print()

    if erreurs:
        sys.exit(1)


if __name__ == "__main__":
    main()
