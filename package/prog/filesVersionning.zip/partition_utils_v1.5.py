# partition_utils.py — Version 1.5
# Traitement partitions musicales avec boutons YouTube
"""
v1.5 :
  - Suppression des messages [DBG]
  - x et y exprimes en % de la page (0-100) depuis le coin bas-gauche
  - Defaut fond_transparent = False (fond blanc opaque)

  Format CSV :
    pdf_name,youtube_url,orientation,fond_transparent,x,y

    orientation      : portrait (defaut) | landscape
    fond_transparent : oui | non (defaut)
    x                : % largeur depuis gauche  (defaut : centre = vide)
    y                : % hauteur depuis le bas  (defaut : 5%)

  Exemple :
    __partition_Auvergnat.pdf,https://youtube.com/watch?v=XXX,landscape,non,,8
"""

version = ("partition_utils.py", "1.5")
print(f"[Import] {version[0]} - Version {version[1]} chargé")

import csv
import re
import unicodedata
from pathlib import Path
from io import BytesIO
from urllib.parse import quote
from typing import Dict, Optional

try:
    from pypdf import PdfReader, PdfWriter
    from reportlab.pdfgen import canvas
    from reportlab.lib.colors import HexColor, white
    HAS_PDF_LIBS = True
except ImportError:
    HAS_PDF_LIBS = False
    print("AVERTISSEMENT : pypdf ou reportlab manquant")
    print("  pip install pypdf reportlab")

# Constantes boutons
BUTTON_WIDTH     = 140
BUTTON_HEIGHT    = 50
BUTTON_SPACING   = 20
DEFAULT_Y_PCT    = 5.0   # % hauteur depuis le bas (defaut)
DEFAULT_X_PCT    = None  # None = centre automatiquement
FOND_PADDING     = 8     # marge fond blanc autour des boutons


# ============================================================================
# DESSIN BOUTONS
# ============================================================================

def draw_button(c, x, y, width, height, color, text):
    """Dessine un bouton arrondi avec icone play."""
    radius = height * 0.4

    c.setFillColor(color)
    c.roundRect(x, y, width, height, radius / 2, fill=1)

    circle_x = x + radius + 5
    circle_y = y + height / 2
    c.setFillColor(white)
    c.circle(circle_x, circle_y, radius, fill=1)

    c.setFillColor(color)
    tri_half = radius * 0.6
    path = c.beginPath()
    path.moveTo(circle_x - tri_half * 0.6, circle_y - tri_half)
    path.lineTo(circle_x - tri_half * 0.6, circle_y + tri_half)
    path.lineTo(circle_x + tri_half, circle_y)
    path.close()
    c.drawPath(path, fill=1, stroke=0)

    c.setFillColor(white)
    c.setFont("Helvetica-Bold", int(height / 3))
    text_x = x + 2 * radius + 10
    text_y = y + (height - int(height / 3)) / 2 - 1
    c.drawString(text_x, text_y, text)


def create_overlay(page_width, page_height, player_url, video_id,
                   x_pct=None, y_pct=None, fond_transparent=False):
    """Cree overlay PDF avec 2 boutons positionnes en %.

    Args:
        page_width, page_height : dimensions page en points PDF
        player_url  : URL lecteur
        video_id    : ID YouTube
        x_pct       : position X en % de la largeur depuis gauche
                      (None = centre automatiquement)
        y_pct       : position Y en % de la hauteur depuis le bas
                      (None = DEFAULT_Y_PCT = 5%)
        fond_transparent : False (defaut) = fond blanc opaque
                           True           = boutons sans fond
    """
    packet = BytesIO()
    c = canvas.Canvas(packet, pagesize=(page_width, page_height))

    total_width = BUTTON_WIDTH * 2 + BUTTON_SPACING

    # Convertir % → points PDF
    y_pct_val = y_pct if y_pct is not None else DEFAULT_Y_PCT
    start_y = (y_pct_val / 100.0) * page_height

    if x_pct is not None:
        start_x = (x_pct / 100.0) * page_width
    else:
        start_x = (page_width - total_width) / 2   # centre

    # Fond blanc opaque si demande
    if not fond_transparent:
        pad = FOND_PADDING
        c.setFillColor(white)
        c.setStrokeColor(white)
        c.rect(
            start_x - pad,
            start_y - pad,
            total_width + 2 * pad,
            BUTTON_HEIGHT + 2 * pad,
            fill=1, stroke=0
        )

    # Bouton rouge YouTube
    draw_button(c, start_x, start_y, BUTTON_WIDTH, BUTTON_HEIGHT,
                HexColor("#FF0000"), "YouTube")
    c.linkURL(
        f"https://youtube.com/watch?v={quote(video_id)}",
        (start_x, start_y, start_x + BUTTON_WIDTH, start_y + BUTTON_HEIGHT),
        relative=0
    )

    # Bouton vert Jouer ici
    x2 = start_x + BUTTON_WIDTH + BUTTON_SPACING
    draw_button(c, x2, start_y, BUTTON_WIDTH, BUTTON_HEIGHT,
                HexColor("#28a745"), "Jouer ici")
    c.linkURL(
        f"{player_url}?v={quote(video_id)}",
        (x2, start_y, x2 + BUTTON_WIDTH, start_y + BUTTON_HEIGHT),
        relative=0
    )

    c.save()
    packet.seek(0)
    return PdfReader(packet)


# ============================================================================
# AJOUT BOUTONS SUR PDF
# ============================================================================

def ajouter_boutons_partition(source_pdf: Path, target_pdf: Path,
                               player_url: str, video_id: str,
                               orientation: str = "portrait",
                               fond_transparent: bool = False,
                               pos_x: float = None,
                               pos_y: float = None) -> bool:
    """Ajoute boutons YouTube sur premiere page partition.

    Args:
        source_pdf       : PDF source (sans boutons)
        target_pdf       : PDF destination (avec boutons)
        player_url       : URL page lecteur
        video_id         : ID video YouTube
        orientation      : "portrait" | "landscape" (info, non utilise pour rotation)
        fond_transparent : False (defaut) = fond blanc opaque
                           True           = pas de fond
        pos_x            : position X en % largeur depuis gauche (None = centre)
        pos_y            : position Y en % hauteur depuis le bas (None = 5%)

    Returns:
        True si succes
    """
    if not HAS_PDF_LIBS:
        print("  ✗ pypdf/reportlab manquant — partition ignoree")
        return False

    try:
        reader = PdfReader(source_pdf)
        writer = PdfWriter()

        first_page = reader.pages[0]
        width  = float(first_page.mediabox.width)
        height = float(first_page.mediabox.height)

        overlay_pdf = create_overlay(
            width, height, player_url, video_id,
            x_pct=pos_x,
            y_pct=pos_y,
            fond_transparent=fond_transparent
        )
        first_page.merge_page(overlay_pdf.pages[0])
        writer.add_page(first_page)

        for page in reader.pages[1:]:
            writer.add_page(page)

        target_pdf.parent.mkdir(parents=True, exist_ok=True)
        with open(target_pdf, "wb") as f:
            writer.write(f)

        return True

    except Exception as e:
        print(f"  ✗ Erreur ajout boutons : {e}")
        return False


# ============================================================================
# LECTURE __correspondance.csv
# ============================================================================

def _normaliser_cle_csv(pdf_name: str) -> str:
    """Normalise une cle pdf_name lue depuis le CSV.

    Retire le prefixe __partition_ (quelle que soit la forme)
    et normalise : minuscules, sans accents, espaces -> underscore.
    """
    nom = pdf_name.strip()
    nom = re.sub(r'^__partition[\s_]+', '', nom, flags=re.IGNORECASE)

    stem = Path(nom).stem
    ext  = Path(nom).suffix

    stem = unicodedata.normalize('NFD', stem)
    stem = ''.join(c for c in stem if unicodedata.category(c) != 'Mn')
    stem = stem.replace("'", "_").replace("\u2019", "_").replace(" ", "_")
    stem = stem.lower()

    return stem + ext.lower()


def _parse_pct(val) -> Optional[float]:
    """Convertit valeur CSV en float (%) ou None si vide/invalide."""
    v = val.strip() if val else ""
    if not v:
        return None
    try:
        return float(v)
    except ValueError:
        return None


def charger_correspondances(csv_path: Path) -> Dict[str, dict]:
    """Charge correspondances partition -> YouTube + parametres depuis CSV.

    Format CSV (colonnes optionnelles apres youtube_url) :
        pdf_name,youtube_url,orientation,fond_transparent,x,y

        pdf_name         : nom du fichier (avec ou sans prefixe __partition_)
        youtube_url      : URL complete YouTube
        orientation      : portrait (defaut) | landscape
        fond_transparent : oui | non (defaut)
        x                : % largeur depuis gauche  (vide = centre)
        y                : % hauteur depuis le bas  (vide = 5%)

    Returns:
        Dict {nom_pdf_normalise: {
            "video_id", "orientation", "fond_transparent", "x", "y"
        }}
    """
    if not csv_path.exists():
        return {}

    correspondances = {}

    try:
        with open(csv_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                pdf_name_brut = row.get("pdf_name", "").strip()
                youtube_url   = row.get("youtube_url", "").strip()

                if not pdf_name_brut:
                    continue

                pdf_name = _normaliser_cle_csv(pdf_name_brut)

                if "v=" in youtube_url:
                    video_id = youtube_url.split("v=")[-1].split("&")[0]
                else:
                    video_id = youtube_url

                orientation = row.get("orientation", "").strip().lower()
                if orientation not in ("portrait", "landscape"):
                    orientation = "portrait"

                fond_str = row.get("fond_transparent", "").strip().lower()
                # "oui"/"yes"/"true"/"1" → transparent ; tout le reste → opaque
                fond_transparent = fond_str in ("oui", "yes", "true", "1")

                correspondances[pdf_name] = {
                    "video_id"        : video_id,
                    "orientation"     : orientation,
                    "fond_transparent": fond_transparent,
                    "x"               : _parse_pct(row.get("x", "")),
                    "y"               : _parse_pct(row.get("y", "")),
                }

        return correspondances

    except Exception as e:
        print(f"  ✗ Erreur lecture correspondances : {e}")
        return {}


# ============================================================================
# TEST REGENERATION
# ============================================================================

def doit_regenerer_partition(source_pdf: Path, target_pdf: Path) -> bool:
    """Verifie si partition doit etre regeneree.

    Regenere si target absent ou source plus recent que target.
    """
    if not target_pdf.exists():
        return True
    return source_pdf.stat().st_mtime > target_pdf.stat().st_mtime

# Fin partition_utils.py v1.5
