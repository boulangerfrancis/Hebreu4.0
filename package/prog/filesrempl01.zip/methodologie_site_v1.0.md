# Méthodologie et Architecture — Site Hébreu 4.0

**Version** : 1.0  
**Projet** : C:\SiteGITHUB\Hebreu4.0  
**Générateur** : genere_site.py v25.1  

---

## Table des matières

1. [Vue d'ensemble](#1-vue-densemble)
2. [Architecture des dossiers](#2-architecture-des-dossiers)
3. [Modules Python](#3-modules-python)
4. [Workflow de génération](#4-workflow-de-génération)
5. [Gestion des partitions musicales](#5-gestion-des-partitions-musicales)
6. [STRUCTURE.py — clé de voûte](#6-structurepy--clé-de-voûte)
7. [Outils de développement et maintenance](#7-outils-de-développement-et-maintenance)
8. [Versioning et déploiement](#8-versioning-et-déploiement)
9. [Manuel utilisateur](#9-manuel-utilisateur)
10. [Référence CSV partitions](#10-référence-csv-partitions)

---

## 1. Vue d'ensemble

Le site est un **générateur de site statique** : il transforme une arborescence de fichiers Word (`.docx`) en un site HTML prêt pour GitHub Pages.

### Principe général

```
documents/          →   prog/genere_site.py   →   html/
  *.docx                                           *.html
  *.pdf                                            *.pdf
  STRUCTURE.py                                     index.html
  __partition_*.docx                               (+ TDM/)
```

Le site est ensuite servi localement via `npx http-server` (lancer.cmd) et publié sur GitHub Pages.

### Technologies

| Couche | Outil |
|--------|-------|
| Documents source | Microsoft Word (.docx) |
| Conversion PDF | PDFCreator (COM Windows) |
| Boutons YouTube | pypdf + reportlab |
| Génération HTML | Python 3 (modules custom) |
| Style | style.css unique |
| Publication | GitHub Pages |
| Test local | npx http-server |

---

## 2. Architecture des dossiers

```
C:\SiteGITHUB\Hebreu4.0\
│
├── documents\              Source : tous les DOCX et fichiers à publier
│   ├── STRUCTURE.py        Structure racine
│   ├── entete_general.html En-tête commun à toutes les pages
│   ├── pied_general.html   Pied de page commun
│   ├── musique\            Dossier player YouTube (créé automatiquement)
│   │   ├── STRUCTURE.py
│   │   ├── entete.html     Player iframe + fallback
│   │   └── entete_general.html
│   └── <sous-dossiers>\
│       ├── STRUCTURE.py
│       ├── *.docx          → converti en *.pdf
│       ├── __partition_*.docx  → PDF avec boutons YouTube
│       └── __correspondance.csv
│
├── html\                   Sortie : site statique (vidé à chaque génération)
│   ├── style.css
│   ├── index.html
│   ├── TDM\
│   └── <miroir de documents\>
│
├── prog\                   Moteur de génération
│   ├── genere_site.py      Point d'entrée
│   ├── settings.py         Configuration centrale
│   ├── documents.py        Conversions PDF + STRUCTURE.py
│   ├── musique.py          Dossier musique + partitions
│   ├── builder.py          Génération HTML
│   ├── docx_to_pdf.py      Conversion via PDFCreator
│   ├── versions.py         Affichage versions modules
│   └── lib1\
│       ├── partition_utils.py  Boutons YouTube sur PDF
│       ├── structure_utils.py  Lecture/écriture STRUCTURE.py
│       ├── html_utils.py
│       ├── fichier_utils.py
│       ├── pdf_utils.py
│       └── style.css
│
└── package\                Archive de déploiement
    └── prog\               Fichiers versionnés prêts à copier
        ├── genere_site_v25.1.py
        ├── musique_v1.4.py
        ├── documents_v2.0.py
        ├── ...
        └── remplace_v2.cmd
```

---

## 3. Modules Python

### `genere_site.py` — Point d'entrée

> Insérer ici le fichier genere_site_v25.1.py

Orchestre les 3 phases de génération. Importe tous les autres modules.  
**Version actuelle** : 25.1

### `settings.py` — Configuration centrale

> Insérer ici le fichier settings_v1.0.py

Remplace les anciens `lib1/config.py` et `lib1/options.py`.  
Contient : `DOSSIER_DOCUMENTS`, `DOSSIER_HTML`, `BASE_PATH`, `CONFIG`.

**Clés CONFIG importantes** :

| Clé | Valeur par défaut | Description |
|-----|-------------------|-------------|
| `regeneration` | `False` | Force la régénération de tous les PDF |
| `titre_site` | `"Hebreu 4.0"` | Titre affiché dans le menu |
| `player_url` | `BASE_PATH/musique/index.html` | URL du player YouTube |
| `dossier_tdm` | `"TDM"` | Nom du dossier table des matières |

### `documents.py` — Gestion documents

> Insérer ici le fichier documents_v2.0.py

- Conversion DOCX→PDF (règles A/B/C/D de régénération)
- Mise à jour STRUCTURE.py (détection nouveaux fichiers)
- Nettoyage `c:\temp` et fichiers `.params` obsolètes

**Règles de régénération PDF** :
- **A** : PDF absent → créer
- **B** : DOCX plus récent que PDF → recréer
- **C** : CONFIG `regeneration=True` → forcer
- **D** : Règle spéciale (voir code)

### `musique.py` — Partitions et player

> Insérer ici le fichier musique_v1.4.py

Responsabilités :
- Création et maintenance de `documents/musique/`
- Lecture du CSV `__correspondance.csv`
- Mise à jour chirurgicale de la clé `"partitions"` dans STRUCTURE.py
- Ajout des boutons YouTube sur les PDF de partitions

### `builder.py` — Génération HTML

> Insérer ici le fichier builder_v1.0.py

Génère les `index.html` de chaque dossier à partir de STRUCTURE.py.  
Gère : navigation fil d'Ariane, en-têtes/pieds, table des fichiers.

### `lib1/partition_utils.py` — Boutons PDF

> Insérer ici le fichier partition_utils_v1.9.py

Dessine les boutons YouTube (rouge) et Jouer ici (vert) sur la première page des PDF de partitions, à la position spécifiée en % de la page.

### `lib1/structure_utils.py` — STRUCTURE.py

> Insérer ici le fichier structure_utils_v2.1.py

Lecture, écriture, et valeurs par défaut des fichiers STRUCTURE.py.  
**Important** : v2.1 corrige la conversion `null`→`None` (JSON→Python).

---

## 4. Workflow de génération

```
lancer.cmd
  └── python genere_site.py
        │
        ├── Vider html\ + copier style.css
        │
        ├── initialiser_dossier_musique()   [musique.py]
        │     Crée documents/musique/ si absent
        │
        ├── PHASE 1 : Pour chaque dossier documents\
        │     ├── traiter_docx_du_dossier()   [documents.py]
        │     │     Convertit *.docx → *.pdf (PDFCreator)
        │     │     Gère aussi __partition_*.docx
        │     ├── traiter_partitions_du_dossier()   [musique.py]
        │     │     Lit __correspondance.csv (si plus récent)
        │     │     Ajoute boutons YouTube sur PDF
        │     │     Met à jour clé "partitions" dans STRUCTURE.py
        │     └── mettre_a_jour_structure()   [documents.py]
        │           Enregistre nouveaux fichiers dans STRUCTURE.py
        │
        ├── PHASE 2 : Pour chaque dossier
        │     generer_page_index()   [builder.py]
        │       → index.html (avec entête, pied, navigation)
        │
        └── PHASE 3 :
              generer_tdm()          [cree_table_des_matieres.py]
              copier_fichiers_site() [builder.py]
                → copie PDF, HTML, images vers html\
```

---

## 5. Gestion des partitions musicales

### Principe

Une partition est un fichier Word avec un accompagnement YouTube :

```
__partition_L'auvergnat de Brassens en hébreu.docx
  ↓ conversion (PHASE 1)
__partition_l_auvergnat_de_brassens_en_hebreu.pdf   ← PDF source
  ↓ ajout boutons YouTube (musique.py)
l_auvergnat_de_brassens_en_hebreu.pdf               ← PDF final (publié)
```

Le bouton **YouTube** ouvre la vidéo sur YouTube.  
Le bouton **Jouer ici** ouvre le player intégré au site (`musique/index.html?v=VIDEO_ID`).

### Fichier `__correspondance.csv`

Placé dans le même dossier que les partitions.  
Colonnes (noms flexibles, insensibles à la casse) :

| Colonne attendue | Variantes acceptées | Valeur par défaut |
|------------------|--------------------|--------------------|
| `nom_partition__pdf` | `pdf_name`, `nom_pdf` | — (obligatoire) |
| `youtube_url` | `url`, `youtube` | — (obligatoire) |
| `orientation` | — | `V` (portrait) |
| `transparence` | `fond_transparent`, `fond` | `0` (fond blanc opaque) |
| `position_Horizontale` | `x`, `pos_x` | centré |
| `position_verticale` | `y`, `pos_y` | `2%` (marge basse) |

**Exemple** :
```
nom_partition__pdf,youtube_url,orientation,transparence,position_Horizontale,position_verticale,
__partition_l_auvergnat_de_brassens_en_hebreu.pdf,https://www.youtube.com/watch?v=morcvF-aFsg,H,100,,,
```

### Paramètres de positionnement des boutons

- **orientation** : `V` (portrait) ou `H` (paysage) — information de contexte
- **transparence** : `0` = fond blanc opaque, `100` = fond invisible (float 0–100)
- **x** : % de la largeur depuis la gauche (float, ex: `10.5`) — vide = centré
- **y** : % de la hauteur depuis le bas (float, ex: `2.5`) — vide = 2% (marge basse)

### Stockage dans STRUCTURE.py

Après le premier passage, `musique.py` injecte une clé `"partitions"` dans le STRUCTURE.py du dossier :

```python
"partitions": [
    {
        "nom_docx"        : "__partition_L'auvergnat de Brassens en hébreu.docx",
        "nom_pdf_source"  : "__partition_l_auvergnat_de_brassens_en_hebreu.pdf",
        "nom_html"        : "l_auvergnat_de_brassens_en_hebreu.pdf",
        "nom_affiche"     : "L'auvergnat de Brassens en hébreu",
        "video_id"        : "morcvF-aFsg",
        "orientation"     : "H",
        "fond_opacite_pct": 100.0,
        "x"               : None,
        "y"               : None,
        "params_signature": "morcvF-aFsg|H|100.0|None|None"
    }
]
```

Le CSV n'est relu que si il est **plus récent** que STRUCTURE.py.  
La `params_signature` permet de détecter un changement de paramètres et de forcer la régénération du PDF.

---

## 6. STRUCTURE.py — Clé de voûte

Chaque dossier de `documents\` contient un fichier `STRUCTURE.py`.  
C'est un fichier Python définissant un dictionnaire `STRUCTURE`.

### Clés du dictionnaire

| Clé | Type | Description |
|-----|------|-------------|
| `titre_dossier` | str | Titre affiché (navigation, page) |
| `nom_navigation` | str | Texte dans le fil d'Ariane |
| `titre_table` | str | Titre au-dessus de la liste des fichiers |
| `entete_general` | bool | Inclure `entete_general.html` racine |
| `pied_general` | bool | Inclure `pied_general.html` racine |
| `entete` | bool | Inclure `entete.html` local |
| `pied` | bool | Inclure `pied.html` local |
| `navigation` | bool | Afficher le fil d'Ariane |
| `ajout_affichage` | bool/list | Colonnes supplémentaires dans la table |
| `affiche_index` | bool | Apparaît dans l'index du parent |
| `affiche_TDM` | bool | Apparaît dans la table des matières |
| `dossiers` | list | Sous-dossiers avec leurs paramètres |
| `fichiers` | list | Fichiers avec leurs paramètres |
| `partitions` | list | **Géré par musique.py** — paramètres YouTube |

### Règle de modification manuelle

- Toutes les clés sauf `"partitions"` peuvent être modifiées manuellement.
- `"partitions"` est géré par `musique.py` — ne pas modifier à la main.
- Les nouvelles entrées `fichiers` sont toujours ajoutées à la fin (position croissante).
- `genere_site.py` ne supprime jamais d'entrée existante.

---

## 7. Outils de développement et maintenance

### `versions.py` — Audit des versions

```
(virPy13) C:\SiteGITHUB\Hebreu4.0\prog> python versions.py
```

Lit le tuple `version` de chaque module sans l'importer (lecture AST).  
Affiche un tableau avec statut (✓ présent / ✗ absent), version, description.

### `remplace_v2.cmd` — Déploiement

```
C:\SiteGITHUB\Hebreu4.0\package\prog\remplace_v2.cmd
```

Copie (sans supprimer) les fichiers versionnés depuis `package\prog\` vers `prog\`.  
Appelle `versions.py` en fin de déploiement pour confirmer les versions installées.

### `lancer.cmd` — Génération et serveur local

> Insérer ici le fichier lancer.cmd

Lance `genere_site.py` puis démarre `npx http-server` sur le port 3500.  
Copie également `style.css` pour permettre un rendu local fidèle.

---

## 8. Versioning et déploiement

### Convention de nommage des fichiers versionnés

```
<module>_v<majeur>.<mineur>.py
```

Exemples :
- `genere_site_v25.1.py`
- `musique_v1.4.py`
- `structure_utils_v2.1.py`

### Règles de versioning

- **Mineur** (ex: 1.3 → 1.4) : correction de bug ou ajout de fonctionnalité limitée
- **Majeur** (ex: 1.x → 2.0) : refactorisation significative ou changement d'interface
- Chaque fichier déclare son `version = ("nom.py", "x.y")` et affiche `[Import] nom.py - Version x.y chargé` au chargement

### Dossier `package\prog\`

Contient **toutes les versions** de tous les fichiers depuis le début du projet.  
Ne jamais supprimer — permet de revenir à une version antérieure.

Structure type :
```
package\prog\
  genere_site_v24.0.py       ← ancienne version conservée
  genere_site_v25.0.py
  genere_site_v25.1.py       ← version courante
  musique_v1.0.py
  musique_v1.1.py
  ...
  musique_v1.4.py            ← version courante
  remplace_v2.cmd            ← déploiement actuel
```

### Workflow de modification

1. Copier le fichier courant depuis `prog\` vers `package\prog\` avec le numéro de version
2. Modifier dans `package\prog\` (jamais directement dans `prog\`)
3. Incrémenter la version dans le code
4. Tester : `lancer.cmd`
5. Valider : `python versions.py`
6. Déployer : `remplace_v2.cmd`

---

## 9. Manuel utilisateur

### Ajouter un nouveau document

1. Placer le fichier `.docx` dans le bon sous-dossier de `documents\`
2. Lancer `lancer.cmd`
3. Le PDF est généré automatiquement et l'entrée ajoutée à `STRUCTURE.py`

### Modifier l'ordre d'affichage

Éditer `STRUCTURE.py` du dossier concerné — modifier la clé `"position"` de chaque entrée dans `"fichiers"`.

### Ajouter une partition musicale

1. Nommer le fichier `__partition_Titre exact.docx`
2. Ajouter une ligne dans `__correspondance.csv` :
   ```
   nom_partition__pdf,youtube_url,orientation,transparence,position_Horizontale,position_verticale,
   __partition_titre_exact.pdf,https://www.youtube.com/watch?v=XXXX,H,0,,2,
   ```
3. Lancer `lancer.cmd`

### Ajuster la position des boutons YouTube

Modifier les colonnes `position_Horizontale` (x%) et `position_verticale` (y%) dans `__correspondance.csv`.  
Supprimer le PDF final (ex: `l_auvergnat.pdf`) pour forcer la régénération, ou modifier le CSV — la détection par `params_signature` régénère automatiquement.

### Forcer la régénération de tous les PDF

Dans `settings.py`, mettre `"regeneration": True`.  
Remettre à `False` après.

### Personnaliser une page

Créer ou modifier `entete.html` et/ou `pied.html` dans le dossier concerné.

---

## 10. Référence CSV partitions

Fichier : `__correspondance.csv`  
Encodage : UTF-8  
Séparateur : virgule `,`

```
nom_partition__pdf,youtube_url,orientation,transparence,position_Horizontale,position_verticale,
__partition_l_auvergnat.pdf,https://www.youtube.com/watch?v=XXX,H,0,,,
__partition_hatikva.pdf,https://www.youtube.com/watch?v=YYY,V,50,10,5,
```

La virgule finale (7e colonne vide) est acceptée et ignorée.

### Valeurs orientation

| Valeur | Variantes acceptées | Résultat |
|--------|--------------------|----|
| `V` | `PORTRAIT`, `P` | Portrait |
| `H` | `LANDSCAPE`, `L`, `PAYSAGE` | Paysage |

### Valeurs transparence

| Valeur | Effet |
|--------|-------|
| `0` | Fond blanc opaque (défaut recommandé sur texte) |
| `50` | Fond semi-transparent |
| `100` | Aucun fond (boutons flottent sur la page) |

---

*Document généré avec le projet — à mettre à jour à chaque version majeure.*
