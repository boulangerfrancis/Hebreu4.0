# musique.py — Version 1.0
# Module MUSIQUE : creation et maintenance du dossier musique/
#
# Responsabilites :
#   - Creer documents/musique/ s'il n'existe pas
#   - Generer entete.html (player YouTube iframe)
#   - Generer entete_general.html (entete sans boutons = page vide propre)
#   - Creer STRUCTURE.py neutre (rien dans affichage ni TDM)
#   - Traiter les partitions __partition_*.docx -> PDF surcharge avec boutons
#     (migre depuis documents.py)
#
# Appele par genere_site.py en debut de PHASE 1

"""
Dossier musique/ dans documents/ :
  - entete.html        : player YouTube (recoit ?v=VIDEO_ID en query param)
  - entete_general.html: identique a entete_general.html racine (sans boutons)
  - STRUCTURE.py       : dossier invisible (ajout_affichage=False, TDM=False)

Le player lit le parametre "v" dans l'URL et embed la video YouTube.
Ex : /Hebreu4.0/html/musique/index.html?v=dQw4w9WgXcQ
"""

import os
from pathlib import Path
from lib1 import partition_utils as partitions
from settings import DOSSIER_DOCUMENTS, DOSSIER_HTML, BASE_PATH, CONFIG

version = ("musique.py", "1.0")
print(f"[Import] {version[0]} - Version {version[1]} charge")

# Nom fixe du dossier musique
NOM_DOSSIER_MUSIQUE = "musique"


# ============================================================================
# TEMPLATES HTML
# ============================================================================

def _template_entete_player(base_path: str, titre_site: str) -> str:
    """Player YouTube embarque dans la mise en page du site.

    Lit le parametre URL ?v=VIDEO_ID et joue la video.
    S'integre dans la structure builder (entete_general + pied_general autour).
    """
    return f"""<!-- entete.html — Player YouTube musique -->
<div class="monTitre">🎵 Lecteur Musical</div>
<div id="player-container" style="
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
    gap: 16px;
">
    <div id="video-wrapper" style="
        width: 100%;
        max-width: 800px;
        aspect-ratio: 16/9;
        background: #000;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 16px rgba(0,0,0,0.3);
    ">
        <iframe
            id="youtube-player"
            width="100%" height="100%"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            style="display:block;">
        </iframe>
    </div>
    <p id="no-video-msg" style="color:#888; font-style:italic; display:none;">
        Aucune vidéo sélectionnée. Ouvrez une partition avec le bouton "Jouer ici".
    </p>
</div>

<script>
(function() {{
    var params = new URLSearchParams(window.location.search);
    var videoId = params.get('v');
    var iframe   = document.getElementById('youtube-player');
    var noMsg    = document.getElementById('no-video-msg');
    var wrapper  = document.getElementById('video-wrapper');

    if (videoId) {{
        iframe.src = 'https://www.youtube.com/embed/' + encodeURIComponent(videoId)
                   + '?autoplay=1&rel=0';
        wrapper.style.display = 'block';
        noMsg.style.display   = 'none';
    }} else {{
        wrapper.style.display = 'none';
        noMsg.style.display   = 'block';
    }}
}})();
</script>
"""


def _template_entete_general_musique() -> str:
    """Entete_general specifique musique : texte discret, sans boutons.

    Affiche juste un sous-titre pour contextualiser la page lecteur.
    """
    return """<!-- entete_general.html — En-tête page musique (sans boutons) -->
<div style="text-align:center; color:#7f8c8d; font-size:0.95em; padding: 8px 0 0 0;">
    Cliquez sur "Jouer ici" depuis une partition pour lancer la musique
</div>
"""


def _template_structure_musique(titre_site: str) -> str:
    """STRUCTURE.py neutre pour le dossier musique.

    Le dossier n'apparait ni dans l'index parent, ni dans la TDM.
    entete=True pour afficher le player.
    navigation=False car c'est une page destination.
    """
    return f'''# STRUCTURE.py – Dossier musique (genere automatiquement)
# Ne pas modifier : sera ecrase a chaque generation si absent.

STRUCTURE = {{
    "titre_dossier"     : "Lecteur Musical",
    "nom_navigation"    : "Musique",
    "titre_table"       : "",
    "entete_general"    : True,
    "pied_general"      : True,
    "entete"            : True,
    "pied"              : False,
    "navigation"        : False,
    "haut_page"         : False,
    "bas_page"          : False,
    "ajout_affichage"   : False,
    "affiche_index"     : False,
    "affiche_TDM"       : False,
    "dossiers"          : [],
    "fichiers"          : []
}}
'''


# ============================================================================
# CREATION / MAINTENANCE DU DOSSIER MUSIQUE
# ============================================================================

def initialiser_dossier_musique(log_func) -> Path:
    """Cree le dossier musique/ et ses fichiers si necessaires.

    Ne touche pas aux fichiers deja presents et corrects.
    Appele en debut de PHASE 1 par genere_site.py.

    Args:
        log_func: Fonction de log

    Returns:
        Path du dossier musique dans documents/
    """
    dossier_musique = Path(DOSSIER_DOCUMENTS) / NOM_DOSSIER_MUSIQUE
    titre_site = CONFIG.get("titre_site", "Site")
    modifie = False

    # Creer le dossier si absent
    if not dossier_musique.exists():
        dossier_musique.mkdir(parents=True)
        log_func(f"  ✓ Dossier musique cree : {dossier_musique}")
        modifie = True

    # entete.html (player)
    entete = dossier_musique / "entete.html"
    if not entete.exists():
        entete.write_text(
            _template_entete_player(BASE_PATH, titre_site),
            encoding="utf-8"
        )
        log_func("  ✓ entete.html (player) cree")
        modifie = True

    # entete_general.html (texte discret sans boutons)
    entete_gen = dossier_musique / "entete_general.html"
    if not entete_gen.exists():
        entete_gen.write_text(
            _template_entete_general_musique(),
            encoding="utf-8"
        )
        log_func("  ✓ entete_general.html cree")
        modifie = True

    # STRUCTURE.py (neutre — invisible dans index et TDM)
    structure = dossier_musique / "STRUCTURE.py"
    if not structure.exists():
        structure.write_text(
            _template_structure_musique(titre_site),
            encoding="utf-8"
        )
        log_func("  ✓ STRUCTURE.py musique cree")
        modifie = True

    if not modifie:
        log_func(f"  ✓ Dossier musique a jour")

    return dossier_musique


# ============================================================================
# TRAITEMENT PARTITIONS (migre depuis documents.py)
# ============================================================================

def nom_partition_depuis_docx(nom_docx: str):
    """Calcule les noms derives d'un fichier __partition_*.docx.

    Args:
        nom_docx: Nom complet du fichier docx (avec prefixe __partition_)

    Returns:
        (nom_lisible, nom_html_normalise)
        Ex: ("L'auvergnat de Brassens", "l_auvergnat_de_brassens.pdf")
    """
    from documents import normaliser_nom
    import re

    sans_prefix = nom_docx
    for prefix in ("__partition_", "__partition _"):
        if nom_docx.lower().startswith(prefix.lower()):
            sans_prefix = nom_docx[len(prefix):]
            break

    stem = Path(sans_prefix).stem
    nom_lisible = stem
    nom_html    = normaliser_nom(stem) + ".pdf"
    return (nom_lisible, nom_html)


def traiter_partitions_du_dossier(dossier: Path, log_func) -> int:
    """Ajoute les boutons YouTube aux partitions PDF du dossier.

    Ne s'execute que si __correspondance.csv est present.

    Chaine complete pour "__partition_Titre.docx" :
      DOCX -> "__partition_titre.pdf"  (via traiter_docx_du_dossier)
      PDF source "__partition_titre.pdf"
      -> PDF final "titre.pdf"  (avec boutons YouTube)

    Seul "titre.pdf" est copie vers html/ (pas le __partition_*).

    Args:
        dossier : Dossier a traiter
        log_func: Fonction de log

    Returns:
        Nombre de partitions traitees
    """
    HAS_PARTITION_LIBS = getattr(partitions, "HAS_PDF_LIBS", False)
    if not HAS_PARTITION_LIBS:
        return 0

    csv_path = dossier / "__correspondance.csv"
    if not csv_path.exists():
        return 0

    log_func(f"  Partitions musicales : {dossier.name}")
    correspondances = partitions.charger_correspondances(csv_path)

    if not correspondances:
        log_func("  ⚠ __correspondance.csv vide ou illisible")
        return 0

    player_url = CONFIG.get("player_url", f"{BASE_PATH}/{NOM_DOSSIER_MUSIQUE}/index.html")
    nb_partitions = 0

    for nom_pdf_final, params in correspondances.items():
        # Extraire parametres
        if isinstance(params, dict):
            video_id         = params["video_id"]
            orientation      = params.get("orientation", "V")
            fond_opacite_pct = params.get("fond_opacite_pct", 0.0)
            pos_x            = params.get("x", None)
            pos_y            = params.get("y", None)
        else:
            video_id         = params
            orientation      = "V"
            fond_opacite_pct = 0.0
            pos_x            = None
            pos_y            = None

        # Chercher le PDF source __partition_*.pdf
        pdf_source = None
        for f in dossier.iterdir():
            if not f.is_file() or f.suffix.lower() != ".pdf":
                continue
            nom_lower = f.name.lower()
            if not (nom_lower.startswith("__partition_") or
                    nom_lower.startswith("__partition _")):
                continue
            _, nom_html_attendu = nom_partition_depuis_docx(f.stem + ".docx")
            if nom_html_attendu == nom_pdf_final:
                pdf_source = f
                break

        if not pdf_source:
            log_func(f"  ⚠ PDF source introuvable pour : {nom_pdf_final}")
            continue

        pdf_final = dossier / nom_pdf_final

        # Verifier si regeneration necessaire (mtime ou params changes)
        if not partitions.doit_regenerer_partition(
            pdf_source, pdf_final,
            video_id         = video_id,
            orientation      = orientation,
            fond_opacite_pct = fond_opacite_pct,
            pos_x            = pos_x,
            pos_y            = pos_y,
        ):
            log_func(f"  ✓ Partition a jour : {nom_pdf_final}")
            continue

        log_func(f"  🎵 {pdf_source.name} -> {nom_pdf_final}")
        success = partitions.ajouter_boutons_partition(
            pdf_source, pdf_final, player_url, video_id,
            orientation      = orientation,
            fond_opacite_pct = fond_opacite_pct,
            pos_x            = pos_x,
            pos_y            = pos_y,
        )

        if success:
            nb_partitions += 1
        else:
            log_func(f"  ✗ Echec ajout boutons : {nom_pdf_final}")

    return nb_partitions

# Fin musique.py v1.0
