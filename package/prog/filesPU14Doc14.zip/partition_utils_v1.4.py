# partition_utils.py — Version 1.4
# Traitement partitions musicales avec boutons YouTube

"""
Module de traitement des partitions avec boutons YouTube.

v1.4 : Paramètres optionnels par ligne dans __correspondance.csv
  Nouveau format CSV :
    pdf_name,youtube_url,orientation,fond_transparent,x,y

  Paramètres optionnels (valeurs par défaut si absents) :
    orientation      : portrait (défaut) | landscape
                       → si landscape : x,y en coordonnées paysage
    fond_transparent : oui (défaut) | non
                       → non = rectangle blanc opaque derrière les boutons
    x                : position horizontale boutons (défaut : centré)
    y                : position verticale boutons depuis le bas (défaut : 40)

  Exemple :
    __partition_L'auvergnat.pdf,https://youtube.com/watch?v=XXX,landscape,non,,50

v1.3 : regex retire __partition_ de la clé CSV quelle que soit la forme
v1.2 : debug [DBG] sur toute la chaîne de traitement
v1.1 : charger_correspondances() normalise la clé pdf_name à la lecture
"""

import csv
from pathlib import Path
from io import BytesIO
from urllib.parse import quote
from typing import Dict, Optional

try:
    from pypdf import PdfReader, PdfWriter
    from reportlab.pdfgen import canvas
    from reportlab.lib.colors import HexColor, white
    HAS_PDF_LIBS = True
except ImportError:
    HAS_PDF_LIBS = False
    print("AVERTISSEMENT : pypdf ou reportlab manquant")
    print("  pip install pypdf reportlab")

# Constantes boutons (valeurs par défaut — surchargées par paramètres CSV)
BUTTON_WIDTH     = 140
BUTTON_HEIGHT    = 50
BUTTON_SPACING   = 20
DEFAULT_MARGIN_Y = 40    # position Y depuis le bas (défaut)
DEFAULT_X        = None  # None = centré automatiquement
DEFAULT_FOND_TRANSPARENT = True  # True = pas de fond, False = fond blanc opaque

# Marge du rectangle fond blanc autour des boutons
FOND_PADDING = 8

def draw_button(c, x, y, width, height, color, text):
    """Dessine un bouton avec cercle play."""
    radius = height * 0.4
    
    # Rectangle arrondi
    c.setFillColor(color)
    c.roundRect(x, y, width, height, radius/2, fill=1)

    # Cercle blanc pour triangle
    circle_x = x + radius + 5
    circle_y = y + height / 2
    c.setFillColor(white)
    c.circle(circle_x, circle_y, radius, fill=1)

    # Triangle dans cercle
    c.setFillColor(color)
    tri_half = radius * 0.6
    path = c.beginPath()
    path.moveTo(circle_x - tri_half*0.6, circle_y - tri_half)
    path.lineTo(circle_x - tri_half*0.6, circle_y + tri_half)
    path.lineTo(circle_x + tri_half, circle_y)
    path.close()
    c.drawPath(path, fill=1, stroke=0)

    # Texte centré
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", int(height/3))
    text_x = x + 2*radius + 10
    text_y = y + (height - int(height/3)) / 2 - 1
    c.drawString(text_x, text_y, text)

def create_overlay(page_width, page_height, player_url, video_id,
                   x=None, y=None, fond_transparent=True):
    """Crée overlay PDF avec 2 boutons.

    Args:
        page_width, page_height : dimensions de la page PDF
        player_url  : URL du lecteur
        video_id    : ID YouTube
        x           : position X du bord gauche des boutons (None = centré)
        y           : position Y depuis le bas (None = DEFAULT_MARGIN_Y)
        fond_transparent : True = pas de fond | False = fond blanc opaque
    """
    packet = BytesIO()
    c = canvas.Canvas(packet, pagesize=(page_width, page_height))

    total_width = BUTTON_WIDTH * 2 + BUTTON_SPACING
    start_x = x if x is not None else (page_width - total_width) / 2
    start_y = y if y is not None else DEFAULT_MARGIN_Y

    # Fond blanc opaque si demandé
    if not fond_transparent:
        pad = FOND_PADDING
        c.setFillColor(white)
        c.setStrokeColor(white)
        c.rect(
            start_x - pad,
            start_y - pad,
            total_width + 2 * pad,
            BUTTON_HEIGHT + 2 * pad,
            fill=1, stroke=0
        )

    # Bouton rouge YouTube
    draw_button(c, start_x, start_y, BUTTON_WIDTH, BUTTON_HEIGHT,
                HexColor("#FF0000"), "YouTube")
    youtube_link = f"https://youtube.com/watch?v={quote(video_id)}"
    c.linkURL(youtube_link,
              (start_x, start_y, start_x + BUTTON_WIDTH, start_y + BUTTON_HEIGHT),
              relative=0)

    # Bouton vert Jouer ici
    x2 = start_x + BUTTON_WIDTH + BUTTON_SPACING
    draw_button(c, x2, start_y, BUTTON_WIDTH, BUTTON_HEIGHT,
                HexColor("#28a745"), "Jouer ici")
    player_link = f"{player_url}?v={quote(video_id)}"
    c.linkURL(player_link,
              (x2, start_y, x2 + BUTTON_WIDTH, start_y + BUTTON_HEIGHT),
              relative=0)

    c.save()
    packet.seek(0)
    return PdfReader(packet)

def ajouter_boutons_partition(source_pdf: Path, target_pdf: Path,
                               player_url: str, video_id: str,
                               orientation: str = "portrait",
                               fond_transparent: bool = True,
                               pos_x: float = None,
                               pos_y: float = None) -> bool:
    """Ajoute boutons YouTube sur première page partition.

    Args:
        source_pdf       : PDF source (sans boutons)
        target_pdf       : PDF destination (avec boutons)
        player_url       : URL page lecteur
        video_id         : ID vidéo YouTube
        orientation      : "portrait" | "landscape"
                           En landscape, la page PDF est lue en paysage :
                           width > height → les coordonnées x,y sont inversées
                           par rapport à l'affichage visuel.
                           Le code tient compte de l'orientation réelle de la page.
        fond_transparent : True = boutons sur fond transparent
                           False = rectangle blanc opaque derrière les boutons
        pos_x            : position X gauche des boutons (None = centré)
        pos_y            : position Y depuis le bas (None = DEFAULT_MARGIN_Y)

    Returns:
        True si succès
    """
    print(f"  [DBG] ajouter_boutons_partition :", flush=True)
    print(f"  [DBG]   source          : {source_pdf}", flush=True)
    print(f"  [DBG]   cible           : {target_pdf}", flush=True)
    print(f"  [DBG]   orientation     : {orientation}", flush=True)
    print(f"  [DBG]   fond_transparent: {fond_transparent}", flush=True)
    print(f"  [DBG]   pos_x           : {pos_x}", flush=True)
    print(f"  [DBG]   pos_y           : {pos_y}", flush=True)

    if not HAS_PDF_LIBS:
        print(f"  [DBG] ✗ HAS_PDF_LIBS=False → abandon", flush=True)
        return False

    try:
        reader = PdfReader(source_pdf)
        writer = PdfWriter()

        first_page = reader.pages[0]
        width  = float(first_page.mediabox.width)
        height = float(first_page.mediabox.height)
        print(f"  [DBG]   page size : {width:.0f} x {height:.0f}", flush=True)

        # En paysage, la page PDF peut avoir width < height selon l'encodage.
        # On utilise l'orientation déclarée dans le CSV pour adapter les coords.
        if orientation == "landscape" and width < height:
            # Page encodée en portrait mais affichée paysage (rotation 90°)
            # Les coordonnées PDF restent en portrait → on travaille normalement
            print(f"  [DBG]   paysage détecté (encodé portrait, rotation 90°)", flush=True)

        overlay_pdf = create_overlay(
            width, height, player_url, video_id,
            x=pos_x,
            y=pos_y,
            fond_transparent=fond_transparent
        )
        first_page.merge_page(overlay_pdf.pages[0])
        writer.add_page(first_page)

        for page in reader.pages[1:]:
            writer.add_page(page)

        target_pdf.parent.mkdir(parents=True, exist_ok=True)
        with open(target_pdf, "wb") as f:
            writer.write(f)

        print(f"  [DBG] ✓ PDF surchargé créé : {target_pdf}", flush=True)
        return True

    except Exception as e:
        print(f"  [DBG] ✗ Erreur ajout boutons : {e}", flush=True)
        return False

def _normaliser_cle_csv(pdf_name: str) -> str:
    """Normalise une clé pdf_name lue depuis le CSV.

    Accepte toutes les variantes naturelles :
      "__partition_blabla et blabla.pdf"          → "blabla_et_blabla.pdf"
      "__partition _blabla et blabla.pdf"          → "blabla_et_blabla.pdf"
      "__partition_l_auvergnat_de_brassens.pdf"    → "l_auvergnat_de_brassens.pdf"
      "blabla_et_blabla.pdf"                       → "blabla_et_blabla.pdf"

    Transformations :
    1. Retirer TOUT préfixe commençant par "__partition" (avec ou sans espace,
       qu'il soit déjà normalisé ou non)
    2. Normaliser le stem restant : minuscules, sans accents, espaces → underscore

    Args:
        pdf_name: Valeur brute de la colonne pdf_name du CSV

    Returns:
        Nom normalisé utilisable comme clé et comme nom de fichier final
    """
    import unicodedata

    nom = pdf_name.strip()

    # Retirer tout préfixe "__partition" suivi de _ ou espace+_
    # Couvre : "__partition_", "__partition _", et variantes déjà normalisées
    import re
    nom = re.sub(r'^__partition[\s_]+', '', nom, flags=re.IGNORECASE)

    # Normaliser le stem : accents, espaces, apostrophes → underscore
    stem = Path(nom).stem
    ext  = Path(nom).suffix  # conserve ".pdf"

    stem = unicodedata.normalize('NFD', stem)
    stem = ''.join(c for c in stem if unicodedata.category(c) != 'Mn')
    stem = stem.replace("'", "_").replace("\u2019", "_").replace(" ", "_")
    stem = stem.lower()

    return stem + ext.lower()


def charger_correspondances(csv_path: Path) -> Dict[str, dict]:
    """Charge correspondances partition → YouTube + paramètres depuis CSV.

    Format CSV (colonnes optionnelles après youtube_url) :
        pdf_name,youtube_url,orientation,fond_transparent,x,y

    Colonnes :
        pdf_name         : nom du fichier (avec ou sans préfixe __partition_)
        youtube_url      : URL complète YouTube
        orientation      : portrait (défaut) | landscape
        fond_transparent : oui (défaut) | non
        x                : position X boutons en points PDF (vide = centré)
        y                : position Y boutons depuis le bas en points PDF
                           (vide = 40)

    Exemples de lignes CSV :
        # Valeurs par défaut (portrait, fond transparent, centré, y=40)
        __partition_Auvergnat.pdf,https://youtube.com/watch?v=XXX

        # Paysage, fond blanc, position personnalisée
        __partition_Auvergnat.pdf,https://youtube.com/watch?v=XXX,landscape,non,100,50

        # Paysage, fond blanc, centré horizontalement, y=50
        __partition_Auvergnat.pdf,https://youtube.com/watch?v=XXX,landscape,non,,50

    Args:
        csv_path: Chemin __correspondance.csv

    Returns:
        Dict {nom_pdf_normalise: {
            "video_id"        : str,
            "orientation"     : "portrait"|"landscape",
            "fond_transparent": bool,
            "x"               : float|None,
            "y"               : float|None
        }}
    """
    print(f"  [DBG] charger_correspondances : {csv_path}", flush=True)

    if not csv_path.exists():
        print(f"  [DBG] ✗ CSV introuvable : {csv_path}", flush=True)
        return {}

    correspondances = {}

    try:
        with open(csv_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            print(f"  [DBG] Colonnes CSV : {reader.fieldnames}", flush=True)

            for i, row in enumerate(reader):
                pdf_name_brut = row.get("pdf_name", "").strip()
                youtube_url   = row.get("youtube_url", "").strip()

                print(f"  [DBG] Ligne {i+1} brute : {dict(row)}", flush=True)

                if not pdf_name_brut:
                    print(f"  [DBG] Ligne {i+1} ignorée : pdf_name vide", flush=True)
                    continue

                # Normaliser la clé
                pdf_name = _normaliser_cle_csv(pdf_name_brut)
                print(f"  [DBG] Ligne {i+1} clé normalisée : {pdf_name_brut!r} → {pdf_name!r}", flush=True)

                # Extraire l'ID vidéo YouTube
                if "v=" in youtube_url:
                    video_id = youtube_url.split("v=")[-1].split("&")[0]
                else:
                    video_id = youtube_url

                # Paramètres optionnels
                orientation = row.get("orientation", "").strip().lower()
                if orientation not in ("portrait", "landscape"):
                    orientation = "portrait"

                fond_str = row.get("fond_transparent", "").strip().lower()
                fond_transparent = fond_str not in ("non", "no", "false", "0")

                def _parse_coord(val):
                    """Convertit valeur CSV en float ou None."""
                    v = val.strip() if val else ""
                    if v == "":
                        return None
                    try:
                        return float(v)
                    except ValueError:
                        return None

                pos_x = _parse_coord(row.get("x", ""))
                pos_y = _parse_coord(row.get("y", ""))

                correspondances[pdf_name] = {
                    "video_id"        : video_id,
                    "orientation"     : orientation,
                    "fond_transparent": fond_transparent,
                    "x"               : pos_x,
                    "y"               : pos_y,
                }
                print(f"  [DBG] Ligne {i+1} params : {correspondances[pdf_name]}", flush=True)

        print(f"  [DBG] {len(correspondances)} correspondance(s) chargée(s)", flush=True)
        return correspondances

    except Exception as e:
        print(f"  [DBG] ✗ Erreur lecture CSV : {e}", flush=True)
        return {}


def doit_regenerer_partition(source_pdf: Path, target_pdf: Path) -> bool:
    """Vérifie si partition doit être regénérée.

    Regénère si:
    - Target inexistant
    - Source plus récent que target

    Args:
        source_pdf: PDF source (sans boutons)
        target_pdf: PDF cible (avec boutons)

    Returns:
        True si regénération nécessaire
    """
    print(f"  [DBG] doit_regenerer_partition :", flush=True)
    print(f"  [DBG]   source : {source_pdf}  existe={source_pdf.exists()}", flush=True)
    print(f"  [DBG]   cible  : {target_pdf}  existe={target_pdf.exists()}", flush=True)

    if not target_pdf.exists():
        print(f"  [DBG]   → Regénération : cible absente", flush=True)
        return True

    src_mtime = source_pdf.stat().st_mtime
    tgt_mtime = target_pdf.stat().st_mtime
    print(f"  [DBG]   mtime source={src_mtime:.0f}  mtime cible={tgt_mtime:.0f}", flush=True)

    if src_mtime > tgt_mtime:
        print(f"  [DBG]   → Regénération : source plus récente", flush=True)
        return True

    print(f"  [DBG]   → Pas de regénération : cible à jour", flush=True)
    return False

# Fin partition_utils.py v1.4
